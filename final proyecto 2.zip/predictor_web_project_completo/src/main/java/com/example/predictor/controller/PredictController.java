package com.example.predictor.controller;

import com.example.predictor.model.Coeficientes;
import com.example.predictor.model.PredictRequest;
import com.example.predictor.model.PredictResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.io.InputStream;

@RestController
@CrossOrigin
@RequestMapping("/predict")
public class PredictController {

    private final Coeficientes coef;

    public PredictController() throws IOException {
        ObjectMapper mapper = new ObjectMapper();

        InputStream input = getClass().getClassLoader().getResourceAsStream("coeficientes.json");
        if (input == null) {
            throw new IOException("No se encontró el archivo coeficientes.json en /resources");
        }

        this.coef = mapper.readValue(input, Coeficientes.class);
    }

    @PostMapping
    public PredictResponse predict(@RequestBody PredictRequest req) {
        double result =
                coef.getIntercepto()
                        + coef.getGre() * req.getGre()
                        + coef.getToefl() * req.getToefl()
                        + coef.getUniversityRating() * req.getUniversityRating()
                        + coef.getSop() * req.getSop()
                        + coef.getLor() * req.getLor()
                        + coef.getCgpa() * req.getCgpa()
                        + coef.getResearch() * req.getResearch();

        double probability = Math.max(0, Math.min(result, 1));
        return new PredictResponse(probability);
    }
}
