package com.example.predictor.model;

public class PredictResponse {
    private double probability;

    public PredictResponse() {}

    public PredictResponse(double probability) {
        this.probability = probability;
    }

    public double getProbability() {
        return probability;
    }

    public void setProbability(double probability) {
        this.probability = probability;
    }
}
