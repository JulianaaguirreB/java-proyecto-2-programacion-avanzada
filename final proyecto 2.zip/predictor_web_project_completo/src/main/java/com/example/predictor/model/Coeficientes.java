package com.example.predictor.model;

public class Coeficientes {
    private double gre;
    private double toefl;
    private double universityRating;
    private double sop;
    private double lor;
    private double cgpa;
    private double research;
    private double intercepto;

    // Getters y Setters
    public double getGre() { return gre; }
    public void setGre(double gre) { this.gre = gre; }

    public double getToefl() { return toefl; }
    public void setToefl(double toefl) { this.toefl = toefl; }

    public double getUniversityRating() { return universityRating; }
    public void setUniversityRating(double universityRating) { this.universityRating = universityRating; }

    public double getSop() { return sop; }
    public void setSop(double sop) { this.sop = sop; }

    public double getLor() { return lor; }
    public void setLor(double lor) { this.lor = lor; }

    public double getCgpa() { return cgpa; }
    public void setCgpa(double cgpa) { this.cgpa = cgpa; }

    public double getResearch() { return research; }
    public void setResearch(double research) { this.research = research; }

    public double getIntercepto() { return intercepto; }
    public void setIntercepto(double intercepto) { this.intercepto = intercepto; }
}
