package com.example.predictor.model;

public class PredictRequest {
    private double gre;
    private double toefl;
    private double universityRating;
    private double sop;
    private double lor;
    private double cgpa;
    private int research;

    public double getGre() { return gre; }
    public void setGre(double gre) { this.gre = gre; }

    public double getToefl() { return toefl; }
    public void setToefl(double toefl) { this.toefl = toefl; }

    public double getUniversityRating() { return universityRating; }
    public void setUniversityRating(double universityRating) { this.universityRating = universityRating; }

    public double getSop() { return sop; }
    public void setSop(double sop) { this.sop = sop; }

    public double getLor() { return lor; }
    public void setLor(double lor) { this.lor = lor; }

    public double getCgpa() { return cgpa; }
    public void setCgpa(double cgpa) { this.cgpa = cgpa; }

    public int getResearch() { return research; }
    public void setResearch(int research) { this.research = research; }
}
